export default function Exibidos(){
    return(
    <div>
        <h1>
            Exibidos
        </h1>
    </div>
    )
}