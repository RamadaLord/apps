export default function Estreias(){
    return(
    <div>
        <h1>
            Estreias
        </h1>
    </div>
    )
}