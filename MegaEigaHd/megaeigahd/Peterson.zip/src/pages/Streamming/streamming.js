export default function Streamming(){
    return(
    <div>
        <h1>
            Streamming
        </h1>
    </div>
    )
}