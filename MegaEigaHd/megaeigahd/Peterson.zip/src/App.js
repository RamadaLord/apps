import Rotas from './Routes'
import '../src/Components/css/style.index.css'
function App() {
  return (
    <Rotas />
  )
}
export default App