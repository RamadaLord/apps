import { Component } from 'react';
import {Button} from 'react-bootstrap';

class Bootstrap extends Component(){

    render( ){
        return(
            <div>
                <h1>
                    a
                </h1>
            </div>
        )
    }
}


export default Bootstrap