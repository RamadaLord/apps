import '../css/style.index.css'

export default function Home() {
    return (
        <div className="dropdown">
            
                <a href="../Home/Home.js">Home</a>
               
           
        </div>
    )
}