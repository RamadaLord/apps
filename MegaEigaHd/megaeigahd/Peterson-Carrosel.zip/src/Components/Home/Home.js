import "../css/style.index.css";
import UncontrolledExample from "../../Components/Bootstrap/caroussel";

export default function Home() {
  return (
    <div>
        
      <header>
        <div className="dropdown">
          <a href="../Home/Home.js">Home</a>
        </div>
      </header>
      <h1>
        <UncontrolledExample/>
      </h1>
    </div>
  );
  
}
