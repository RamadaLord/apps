export default function PopularesSeries(){
    return(
    <div>
        <h1>
            Series Populares
        </h1>
    </div>
    )
}