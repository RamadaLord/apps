export default function PopularesFilmes(){
    return(
    <div>
        <h1>
            Populares
        </h1>
    </div>
    )
}