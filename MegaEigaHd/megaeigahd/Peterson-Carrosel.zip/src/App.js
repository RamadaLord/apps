import Rotas from './Routes'
import 'bootstrap/dist/css/bootstrap.min.css'
import '../src/Components/css/style.index.css'

function App() {
  return (
    <Rotas />
    
  )
}
export default App